

//独立COOKIE文件     ck在``里面填写，多账号换行
let GetUserInfourlVal= ``
let GetUserInfoheaderVal= `{"Cookie":"app_cityid=310100; app_provinceid=310000; app_deviceid=6154af4f4842c28bced6c498b30eadbef2216e63; app_devicename=iPhone; app_key=autospeed_ios; app_platform=iPhone; app_sign=73976CF52D93F70AE7D449B2C61ED2B9; app_sysver=14.4; app_userid=86364159; app_ver=1.7.1; device_standard=iPhone12,3; pcpopclub=7dbf41a0b6b54a33a0cb75217d4866660525cfff; sessionlogin=; ahpvno=3; __ah_uuid_ng=u_86364159; fvlid=16109865251596u4VrKJmfS; area=819999; autoid=0fd21fdcd6bfdabe26c319487ac89f2f; ref=0%7C0%7C0%7C0%7C2021-01-11+12%3A24%3A23.955%7C2021-01-11+12%3A22%3A41.521; sessionip=23.99.122.226; v_no=2; visit_info_ad=D8D59E16-F3A3-42AD-A580-7E9BD6B0FF01||29EFBEB2-03A9-45DD-8147-15A90F9C2A5B||-1||-1||2; ahpau=1; sessionid=D8D59E16-F3A3-42AD-A580-7E9BD6B0FF01%7C%7C2021-01-11+12%3A22%3A41.521%7C%7C0","apisign":"1|6154af4f4842c28bced6c498b30eadbef2216e63|autohomebrush|1611108981|F7C7007E045C6558BB78A30DB9620E4A","reqid":"6154af4f4842c28bced6c498b30eadbef2216e63/1611108981961/715","Accept":"*/*","Accept-Encoding":"gzip, deflate, br","Host":"mobile.app.autohome.com.cn","User-Agent":"iPhone\t14.4\tautohome\t1.7.1\tiPhone","Connection":"keep-alive","Accept-Language":"zh-Hans;q=1"}`
let coinbodyVal= ``
let taskbodyVal= `_sign=EE607CAD305E24270EFFE86CB3F0FA33&a=18&auth=7dbf41a0b6b54a33a0cb75217d4866660525cfff&autohomeua=iPhone%0914.4%09autohome%091.7.1%09iPhone&deviceid=6154af4f4842c28bced6c498b30eadbef2216e63&model=1&pm=1&timestamp=1610854411&v=1.7.1`
let activitybodyVal= `_sign=18A8E6D86DE834DE6F69A3474EC3E681&a=18&abtest=a&auth=7dbf41a0b6b54a33a0cb75217d4866660525cfff&autohomeua=iPhone%0914.4%09autohome%091.7.1%09iPhone&deviceid=6154af4f4842c28bced6c498b30eadbef2216e63&pm=1&svs=1&timestamp=1610854411&v=1.7.1`
let GoldcoinbodyVal= ``
let videobodyVal= ``
let WelfarevideobodyVal= ``
let WelfarebodyVal= ``
let addCoinbodyVal= `_sign=5C0C6D281ABFA7AE356CB475D8F13DDB&_timestamp=1611108564&a=18&autohomeua=iPhone%0914.4%09autohome%091.7.1%09iPhone&deviceid=6154af4f4842c28bced6c498b30eadbef2216e63&moreflag=0&pm=1&source_channel_id=3503&user_id=86364159&v=1.7.1`
let addCoin2bodyVal= `_sign=F7499ABA0EB3B703091C457A1D68F181&_timestamp=1610597405&a=18&autohomeua=iPhone%0914.4%09autohome%091.7.1%09iPhone&deviceid=6154af4f4842c28bced6c498b30eadbef2216e63&moreflag=1&pm=1&source_channel_id=3503&user_id=86364159&v=1.7.1`
let reportAssbodyVal= ``
let reportAssheaderVal= ``
let cointowalletbodyVal= ``


let qczjcookie = {
  GetUserInfourlVal: GetUserInfourlVal,	
  GetUserInfoheaderVal: GetUserInfoheaderVal,  
  coinbodyVal: coinbodyVal,
  taskbodyVal: taskbodyVal,
  activitybodyVal: activitybodyVal,
  GoldcoinbodyVal: GoldcoinbodyVal,  
  videobodyVal: videobodyVal,  
  WelfarevideobodyVal: WelfarevideobodyVal,  
  WelfarebodyVal: WelfarebodyVal,  
  addCoinbodyVal: addCoinbodyVal,
  addCoin2bodyVal: addCoin2bodyVal,    
  reportAssbodyVal: reportAssbodyVal, 
  reportAssheaderVal: reportAssheaderVal,  
  cointowalletbodyVal: cointowalletbodyVal,

}

module.exports =  qczjcookie
  